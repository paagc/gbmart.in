<?php return array (
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'gloudemans/shoppingcart' => 
  array (
    'providers' => 
    array (
      0 => 'Gloudemans\\Shoppingcart\\ShoppingcartServiceProvider',
    ),
    'aliases' => 
    array (
      'Cart' => 'Gloudemans\\Shoppingcart\\Facades\\Cart',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'pulkitjalan/google-apiclient' => 
  array (
    'providers' => 
    array (
      0 => 'PulkitJalan\\Google\\GoogleServiceProvider',
    ),
    'aliases' => 
    array (
      'Google' => 'PulkitJalan\\Google\\Facades\\Google',
    ),
  ),
);