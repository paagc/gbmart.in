@extends('admin.app')

@section('content_header')
<h1>
  Dashboard 
  <small>Reports and more</small>
</h1>
<ol class="breadcrumb">
  <li><a href="#">Home</a></li>
  <li class="active">Dashboard</li>
</ol>
@endsection

@section('content')
<h2>Under Development</h2>
@endsection