<table width="100%" border="1" cellpadding="5" cellspacing="0">

  <tr>
    <td colspan="2" align="center" style="font-size:18px"><b>Invoice</b></td>
  </tr>

  <tr>
    <td colspan="2">
      <table width="100%" cellpadding="5">
        <tr>
          <td width="65%">
            To,<br />
            <b>RECEIVER (BILL TO)</b><br />
            Name : Prasoon Sanwal<br /> 
            Billing Address : Billing Address<br />
            Phone : +91-8123230294<br />
          </td>

          <td width="35%">
            <br />
            <img src="images/logo.png" width="150px" /><br />
            Invoice No. : 123<br />
            Invoice Date : Today Date <br />
          </td>
        </tr>
      </table>
      <br />
      <table width="100%" border="1" cellpadding="5" cellspacing="0">
        <tr>
          <th>Sr No.</th>
          <th>Item Name</th>
          <th>Quantity</th>
          <th>Price</th>
          <th>Actual Amt.</th>
          <th colspan="2">CGST (%)</th>
          <th colspan="2">SGST (%)</th>
          <th colspan="2">OTHER (%)</th>
          <th rowspan="2">Total</th>
        </tr>
        <tr>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th></th>
          <th>Rate</th>
          <th>Amt.</th>
          <th>Rate</th>
          <th>Amt.</th>
          <th>Rate</th>
          <th>Amt.</th>
        </tr>
        <tr>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>
          <td>1</td>

        </tr>


        <tr>
          <td align="right" colspan="11"><b>Total</b></td>
          <td align="right"><b>123</b></td>
        </tr>
        <tr>
          <td colspan="11"><b>Total Amt. Before Tax :</b></td>
          <td align="right">123</td>
        </tr>
        <tr>
          <td colspan="11">Add : CGST :</td>
          <td align="right">123</td>
        </tr>
        <tr>
          <td colspan="11">Add : SGST :</td>
          <td align="right">123</td>
        </tr>
        <tr>
          <td colspan="11">Add : OTHER :</td>
          <td align="right">123</td>
        </tr>
        <tr>
          <td colspan="11"><b>Total Tax Amt.  :</b></td>
          <td align="right">123</td>
        </tr>
        <tr>
          <td colspan="11"><b>Total Amt. After Tax :</b></td>
          <td align="right">123</td>
        </tr>

      </table>
    </td>
  </tr>
</table>