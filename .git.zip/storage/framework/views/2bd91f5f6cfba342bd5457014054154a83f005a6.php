<?php $__env->startSection('content_header'); ?>
<h1>
	Pending Orders
</h1>
<ol class="breadcrumb">
	<li><a href="/seller">Home</a></li>
	<li><a href="/orders">Orders</a></li>
	<li class="active">Pending Orders</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-body">
				<form action="/seller/orders/pending" method="GET">
					<table class="table table-bordered">
						<thead>
							<tr>
								<th>Order #</th>
								<th>Product</th>
								<th>Count</th>
								<th>Price</th>
								<th>Delivery Charge</th>
								<th>Total Amount</th>
								<th>Payment Method</th>
								<th>Placed At</th>
								<th></th>
							</tr>
						</thead>
						<tbody>
							<?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($order->id); ?></td>
								<td><?php echo e($order->seller_product->product->name); ?></td>
								<td><?php echo e($order->count); ?></td>
								<td><?php echo e($order->price); ?></td>
								<td><?php echo e($order->delivery_charge); ?></td>
								<td><?php echo e($order->total_amount); ?></td>
								<td><?php echo e($order->payment_method); ?></td>
								<td><?php echo e(date('d-m-y h:i:sa', strtotime($order->created_at) + 19800)); ?></td>
								<td class="text-center"><a class="btn btn-xs show-detail" order-id="<?php echo e($order->id); ?>"><i class="fa fa-arrow-down"></i></a></td>
							</tr>
							<tr class="order-detail hide" order-id="<?php echo e($order->id); ?>">
								<td colspan="9">
									<div class="box box-solid">
										<div class="box-body">
											<div class="row">
												<div class="col-md-4">
													<dl>
														<dt>Order #</dt>
														<dd><?php echo e($order->id); ?></dd>
														<dt>Order Date & Time</dt>
														<dd><?php echo e(date('d-m-y h:i:sa', strtotime($order->created_at) + 19800)); ?></dd>
														<dt>Product</dt>
														<dd><?php echo e($order->product->name); ?></dd>
														<dt>Payment Method</dt>
														<dd><?php echo e($order->payment_method); ?></dd>
														<dt>Payment Ref. #</dt>
														<dd><?php echo e($order->payment_reference); ?></dd>
													</dl>
												</div>
												<div class="col-md-4">
													<dl>
														<dt>Order Status</dt>
														<dd style="color: #0016a8; font-weight: 700;">
															<?php echo e($order->status); ?>

														</dd>
														<dt>Quantity</dt>
														<dd><?php echo e($order->count); ?></dd>
														<dt>Price</dt>
														<dd>Rs <?php echo e($order->price); ?></dd>
														<dt>Delivery Charge</dt>
														<dd>Rs <?php echo e($order->delivery_charge); ?></dd>
														<dt>Total Amount</dt>
														<dd>Rs <?php echo e($order->total_amount); ?></dd>
													</dl>
												</div>
												<div class="col-md-4">
													<dl>
														<dt>Extra Detail</dt>
														<dd><?php echo e($order->extra); ?></dd>
														<dt>Customer Name</dt>
														<dd><?php echo e($order->customer->name); ?></dd>
														<dt>Customer Mobile Number</dt>
														<dd><?php echo e($order->customer->mobile_number); ?></dd>
														<dt>Shipping Address</dt>
														<dd><?php echo e($order->address); ?></dd>
														<dt>Shipping City/Town</dt>
														<dd><?php echo e($order->city); ?></dd>
														<dt>Shipping State</dt>
														<dd><?php echo e($order->state); ?></dd>
														<dt>Shipping PIN Code</dt>
														<dd><?php echo e($order->postal_code); ?></dd>
													</dl>
												</div>
												<div class="col-md-6">
													<h4>Order Log</h4>
													<table class="table table-bordered">
														<tr>
															<th>Status</th>
															<th>Date & Time</th>
															<th>Remarks</th>
														</tr>
														<?php $__currentLoopData = $order->order_logs()->orderBy('created_at', 'desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<tr>
															<td><?php echo e($log->status); ?></td>
															<td><?php echo e(date('d-m-y h:i:sa', strtotime($log->created_at) + 19800)); ?></td>
															<td><?php echo e($log->remarks); ?></td>
														</tr>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</table>
												</div>
											</div>
										</div>
										<div class="box-footer">
											<div class="input-group">
												<div class="input-group-btn">
													<button type="button" class="btn pull-right hide-detail"><i class="fa fa-arrow-up"></i></button>
													<?php if($order->status == 'PENDING'): ?>
													<button type="button" class="btn btn-success pull-right change-status" order-id="<?php echo e($order->id); ?>" status="approved">Mark as Approved</button>
													<button type="button" class="btn btn-danger pull-right change-status" order-id="<?php echo e($order->id); ?>" status="rejected">Mark as Rejected</button>
													<?php elseif($order->status == 'APPROVED'): ?>
													<button type="button" class="btn btn-success pull-right change-status" order-id="<?php echo e($order->id); ?>" status="packed">Mark as Packed</button>
													<?php elseif($order->status == 'PACKED'): ?>
													<button type="button" class="btn btn-success pull-right change-status" order-id="<?php echo e($order->id); ?>" status="shipped">Mark as Shipped</button>
													<?php elseif($order->status == 'SHIPPED'): ?>
													<button type="button" class="btn btn-success pull-right change-status" order-id="<?php echo e($order->id); ?>" status="shipped">Mark as Shipped</button>
													<?php endif; ?>
													<?php if($order->status == 'PENDING' || $order->status == 'APPROVED' || $order->status == 'PACKED' || $order->status == 'SHIPPED'): ?>
													<div class="row">
														<div class="col-md-4 pull-right">
															<input type="text" class="form-control order-remarks" placeholder="Remarks..." minlength="5" maxlength="25">
														</div>
													</div>
													<?php endif; ?>
												</div>
											</div>
										</div>
									</div>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr>
								<td colspan="8" class="text-center">No Orders Available</td>
							</tr>
							<?php endif; ?>
						</tbody>
					</table>
				</form>
			</div>
			<div class="box-footer clearfix">
				<?php echo e($orders->appends(app('request')->all())->render()); ?>

			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
	$(document).ready(function () {
		$('.show-detail').click(function () {
			$('tr.order-detail').addClass('hide');
			var orderId = $(this).attr('order-id');
			$('tr.order-detail[order-id="' + orderId + '"]').removeClass('hide');
		});
		$('.hide-detail').click(function () {
			$('tr.order-detail').addClass('hide');
		});
		$('.change-status').click(function () {
			var orderId = $(this).attr('order-id');
			var status = $(this).attr('status');
			var url = "/seller/orders/id/" + orderId + "/status-update/" + status;
			var remarks = $('input.order-remarks').val();
			if (remarks && remarks.length > 4) {
				url += '?remarks=' + encodeURI(remarks);
			}
			window.location.href = url;
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('seller.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>