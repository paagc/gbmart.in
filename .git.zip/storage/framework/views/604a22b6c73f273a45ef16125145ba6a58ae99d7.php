<?php $__env->startSection('content'); ?>
<div class="breadcrumb">
	<div class="container">
		<div class="breadcrumb-inner">
			<ul class="list-inline list-unstyled">
				<li><a href="\">Home</a></li>
				<li><a href="#"><?php echo e($sub_category->category->display_name); ?></a></li>
				<li class='active'><?php echo e($sub_category->display_name); ?></li>
			</ul>
		</div>
	</div>
</div>
<div class="body-content outer-top-xs">
	<div class='container'>
		<div class='row'>
			<div class='col-md-3 sidebar'>
				<div class="sidebar-module-container">
					<div class="sidebar-filter">
						<div class="sidebar-widget wow fadeInUp">
							<h3 class="section-title">Shop By &nbsp;&nbsp;&nbsp;&nbsp;<button class="btn btn-primary filter-button">Filter</button></h3>
							<div class="widget-header">
								<h4 class="widget-title">Brands</h4>
							</div>
							<div class="sidebar-widget-body">
								<ul>
									<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="checkbox"> <label> <input type="checkbox" class="check-brand" data-value="<?php echo e($brand); ?>" <?php if(in_array($brand, $selected_brands)): ?> checked <?php endif; ?>> <?php echo e($brand); ?> </label> </div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
						</div>

						<div class="sidebar-widget wow fadeInUp">
							<div class="widget-header">
								<h4 class="widget-title">Price Slider</h4>
							</div>
							<div class="sidebar-widget-body m-t-10">
								<div class="price-range-holder">
									<span class="min-max">
										<span class="pull-left"><span class="fa fa-inr"></span><?php echo e($price_range_min); ?></span>
										<span class="pull-right"><span class="fa fa-inr"></span><?php echo e($price_range_max); ?></span>
									</span>
									<input type="text" id="amount" style="border:0; color:#666666; font-weight:bold;text-align:center;">

									<input type="text" class="price-range-slider" value="<?php echo e($price_min); ?>,<?php echo e($price_max); ?>" >
								</div>
							</div>
						</div>

						<?php if(count($featured_products) > 0): ?>
						<div class="sidebar-widget outer-bottom-small wow fadeInUp">
							<h3 class="section-title">FEATURED PRODUCTS</h3>
							<div class="sidebar-widget-body outer-top-xs">
								<div class="owl-carousel sidebar-carousel special-offer custom-carousel owl-theme outer-top-xs">
									<div class="item">
										<div class="products special-product custom-product-boxes">
											<?php $__currentLoopData = $featured_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="product custom-product-box">
												<div class="product-micro">
													<div class="row product-micro-row">
														<div class="col col-xs-5">
															<div class="product-image">
																<div class="image custom-product-image"> 
																	<a href="/store/<?php echo e($seller_product->product->category->name); ?>/<?php echo e($seller_product->product->sub_category->name); ?>/<?php echo e($seller_product->product->name); ?>-<?php echo e($seller_product->id); ?>"> 
																		<img src="<?php echo e($seller_product->product->product_images[0]->url); ?>" alt=""> 
																	</a> 
																</div>
															</div>
														</div>

														<div class="col col-xs-7">
															<div class="product-info">
																<h3 class="name">
																	<a href="/store/<?php echo e($seller_product->product->category->name); ?>/<?php echo e($seller_product->product->sub_category->name); ?>/<?php echo e($seller_product->product->name); ?>-<?php echo e($seller_product->id); ?>"><?php echo e((strlen($seller_product->product->display_name) > 20 ? substr($seller_product->product->display_name, 0, 15) . "..." : $seller_product->product->display_name)); ?></a>
																</h3>
																<div class="rating rateit-small"></div>
																<div class="product-price"> <span class="price"><span class="fa fa-inr"></span><?php echo e(number_format($seller_product->seller_price, 2, '.', ',')); ?> </span> </div>
															</div>
														</div>
													</div>
												</div>
											</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php endif; ?>

					</div>
				</div>
			</div>
			<div class='col-md-9'>
				<div id="hero">
					<div id="owl-main" class="owl-carousel owl-inner-nav owl-ui-sm">
						<div class="item" style="background-image: url(/assets/images/sliders/01.jpg);">
							<div class="container-fluid">
							</div>
						</div>

						<div class="item" style="background-image: url(/assets/images/sliders/02.jpg);">
							<div class="container-fluid">
							</div>
						</div>
					</div>
				</div>

				<div class="clearfix filters-container m-t-10">
					<div class="row">
					</div>
				</div>
				<div class="search-result-container ">
					<div id="myTabContent" class="tab-content category-list">
						<div class="tab-pane active " id="grid-container">
							<div class="category-product">
								<div class="row custom-product-boxes">
									<?php if(count($seller_products) > 0): ?>
									<?php $__currentLoopData = $seller_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="col-sm-6 col-md-4 wow fadeInUp custom-product-box">
										<div class="products">
											<div class="product">		
												<div class="product-image">
													<div class="image custom-product-image">
														<a href="/store/<?php echo e($seller_product->product->category->name); ?>/<?php echo e($seller_product->product->sub_category->name); ?>/<?php echo e($seller_product->product->name); ?>-<?php echo e($seller_product->id); ?>">
															<img  src="<?php echo e($seller_product->product->product_images[0]->url); ?>" alt="">
														</a>
													</div>
												</div>
												<div class="product-info text-left">
													<h3 class="name"><a href="/store/<?php echo e($seller_product->product->category->name); ?>/<?php echo e($seller_product->product->sub_category->name); ?>/<?php echo e($seller_product->product->name); ?>-<?php echo e($seller_product->id); ?>"><?php echo e((strlen($seller_product->product->display_name) > 20 ? substr($seller_product->product->display_name, 0, 15) . "..." : $seller_product->product->display_name)); ?></a></h3>
													<div class="rating rateit-small"></div>
													<div class="description"><?php echo e($seller_product->product->description_small); ?></div>

													<div class="product-price">	
														<span class="price fa fa-inr">
															<?php echo e(number_format($seller_product->seller_price, 2, '.', ',')); ?>				</span>
															<span class="price-before-discount fa fa-inr"><?php echo e(number_format($seller_product->product->original_price, 2, '.', ',')); ?></span>

														</div>

													</div>
													<div class="cart clearfix animate-effect">
														<div class="action">
															<ul class="list-unstyled">
																<li class="add-cart-button btn-group">
																	<button seller-product-id="<?php echo e($seller_product->id); ?>" class="btn btn-primary icon seller-product" data-toggle="dropdown" type="button">
																		<i class="fa fa-shopping-cart"></i>													
																	</button>
																	<button seller-product-id="<?php echo e($seller_product->id); ?>" class="btn btn-primary cart-btn seller-product" type="button">Add to cart</button>

																</li>

																<li class="lnk wishlist">
																	<a class="add-to-cart" title="Wishlist">
																		<i class="icon fa fa-heart"></i>
																	</a>
																</li>

																<li class="lnk">
																	<a seller-product-id="<?php echo e($seller_product->id); ?>" class="add-to-cart buy-now" title="Buy now">
																		<i class="fa fa-shopping-bag"></i>
																	</a>
																</li>
															</ul>
														</div>
													</div>
												</div>

											</div>
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php else: ?>
										<h3 class="text-center">No products found.</h3>
										<?php endif; ?>
									</div><!-- /.row -->
								</div><!-- /.category-product -->
							</div><!-- /.tab-pane -->
						</div><!-- /.tab-content -->

						<?php 
						$url = url()->full();
						$url = str_replace("?page=" . $page, "", $url);
						$url = str_replace("&page=" . $page, "", $url);
						$url_query_append = "?";
						if (stripos($url, "?")) {
							$url_query_append = "&";
						}
						?>
						<?php if($page_count > 1): ?>
						<div class="clearfix filters-container">
							<div class="text-right">
								<div class="pagination-container">
									<ul class="list-inline list-unstyled">
										<?php if($page > 1): ?>
										<li class="prev"><a href="<?php echo e($url . $url_query_append . "page=" . ($page - 1)); ?>"><i class="fa fa-angle-left"></i></a></li>
										<?php endif; ?>

										<?php for($i = 1; $i <= $page_count; $i++): ?>
										<li <?php if($page == $i): ?> class="active" <?php endif; ?>><a href="<?php echo e($url . $url_query_append . "page=" . $i); ?>"><?php echo e($i); ?></a></li>
										<?php endfor; ?>

										<?php if($page == $page_count): ?>
										<li class="next"><a href="<?php echo e($url . $url_query_append . "page=" . ($page + 1)); ?>"><i class="fa fa-angle-right"></i></a></li>
										<?php endif; ?>
									</ul>
								</div>						    
							</div>
						</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<script>
	jQuery(function () {

		if (jQuery('.price-range-slider').length > 0) {
			jQuery('.price-range-slider').slider({
				min: <?php echo e($price_range_min); ?>,
				max: <?php echo e($price_range_max); ?>,
				step: 100,
				value: [<?php echo e($price_min); ?>, <?php echo e($price_max); ?>],
				handle: "square"
			});
		}

		function filter() {
			var url = "<?php echo e(url()->current()); ?>";
			var selected_brands = [];
			var price_min = <?php echo e($price_min); ?>, price_max = <?php echo e($price_max); ?>, price_range_min = <?php echo e($price_range_min); ?>, price_range_max = <?php echo e($price_range_max); ?>;
			var page = <?php echo e($page); ?>;
			$('.check-brand').each(function () {
				if($(this).prop('checked') == true) {
					selected_brands.push($(this).attr('data-value'));
				}
			});
			var price_values = $('input.price-range-slider').val().split(',');
			if (price_values.length == 2) {
				price_min = parseInt(price_values[0]);
				price_max = parseInt(price_values[1]);
			}
			if (selected_brands.length > 0 || price_min != price_range_min || price_max != price_range_max) {
				url += "?";
				if (selected_brands.length > 0) {
					for (var i = 0; i < selected_brands.length; i++) {
						url += ((url.split('?')[1].length > 0 ? "&" : "")) + "selected_brands[]=" + selected_brands[i];
					}
				}
				if (price_min != price_range_min) {
					url += ((url.split('?')[1].length > 0 ? "&" : "")) + "price_min=" + price_min;
				}
				if (price_max != price_range_max) {
					url += ((url.split('?')[1].length > 0 ? "&" : "")) + "price_max=" + price_max;
				}
				if (page > 1) {
					url += ((url.split('?')[1].length > 0 ? "&" : "")) + "page=" + page;
				}
			}

			window.location.href = url;
		}

		$('.filter-button').click(filter);

        $('.seller-product').click(function () {
            window.location.href = '/store/cart/add/' + $(this).attr('seller-product-id');
        });
        
        $('.buy-now').click(function () {
            window.location.href = '/store/cart/buy-now/' + $(this).attr('seller-product-id');
        });
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>