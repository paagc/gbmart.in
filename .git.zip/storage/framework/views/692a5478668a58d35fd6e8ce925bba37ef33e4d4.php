<?php $__env->startSection('content_header'); ?>
<h1>
	Create Coupon
</h1>
<ol class="breadcrumb">
	<li><a href="/admin">Home</a></li>
	<li><a href="/admin/gift-coupon">Gift Coupon</a></li>
	<li class="active">Create</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="box box-primary">
			<form role="form" action="/admin/gift-coupon/create" method="POST" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<div class="box-body">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label for="code">Code<span class="text-danger"> *</span></label>
								<input type="text" name="code" class="form-control" id="code" placeholder="Enter Code" value="<?php echo e(old('code')); ?>">
								<?php if($errors->has('code')): ?>
							    <span class="text-danger"><?php echo e($errors->first('code')); ?></span>
							    <?php endif; ?>
							</div>
						</div>

						<div class="col-md-4">
							<div class="form-group">
								<label for="value">Value<span class="text-danger"> *</span></label>
								<input type="text" name="value" class="form-control" id="value" placeholder="Enter Value" value="<?php echo e(old('value')); ?>">
								<?php if($errors->has('value')): ?>
							    <span class="text-danger"><?php echo e($errors->first('value')); ?></span>
							    <?php endif; ?>
							</div>
						</div>

						<div class="col-md-4">
							<div class="form-group">
								<label for="type">Type<span class="text-danger"> *</span></label>
								<select name="type" class="form-control" id="type" placeholder="Coupon Type">
									<option></option>
									<option value="PERCENTAGE" <?php if(old('type') == 'PERCENTAGE'): ?> selected <?php endif; ?>>Percentage</option>
									<option value="ABSOLUTE" <?php if(old('type') == 'ABSOLUTE'): ?> selected <?php endif; ?>>Absolute</option>
								</select>
								<?php if($errors->has('type')): ?>
							    <span class="text-danger"><?php echo e($errors->first('type')); ?></span>
							    <?php endif; ?>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label for="max_amount">Max Amount<span class="text-danger"> *</span></label>
								<input type="text" name="max_amount" class="form-control" id="max_amount" placeholder="Max Amount" value="<?php echo e(old('max_amount')); ?>">
								<?php if($errors->has('max_amount')): ?>
							    <span class="text-danger"><?php echo e($errors->first('max_amount')); ?></span>
							    <?php endif; ?>
							</div>
						</div>

						<div class="col-md-4">
							<div class="form-group">
								<label for="end_date">End Date<span class="text-danger"> *</span></label>
								<input type="date" name="end_date" class="form-control" id="end_date" value="<?php echo e(old('end_date')); ?>">
								<?php if($errors->has('end_date')): ?>
							    <span class="text-danger"><?php echo e($errors->first('end_date')); ?></span>
							    <?php endif; ?>
							</div>
						</div>
					</div>
				</div>
				<div class="box-footer">
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>