<?php $__env->startSection('content'); ?>
<div class="breadcrumb">
	<div class="container">
		<div class="breadcrumb-inner">
			<ul class="list-inline list-unstyled">
				<li><a href="home.html">Home</a></li>
				<li class='active'>Login</li>
			</ul>
		</div>
	</div>
</div>
<div class="body-content">
	<div class="container">
		<div class="sign-in-page">
			<div class="row">
				<div class="col-md-12 col-sm-12 create-new-account">
					<h4 class="checkout-subtitle">Create a new account</h4>
					<p class="text title-tag-line">Create your new account.</p>
					<form class="register-form outer-top-xs" role="form" action="/seller/register" method="POST">
						<?php echo e(csrf_field()); ?>

						<input type="hidden" name="type" value="seller">

						<?php if(Session::has('error')): ?>
						<p style="text-align: center; color: red;"><?php echo e(Session::get('error')); ?></p>
						<?php endif; ?>
						<div class="form-group row">
							<div class="col-sm-6 col-md-6">
								<label class="info-title" for="exampleInputEmail2">Email Address <span>*</span></label>
								<input type="email" class="form-control unicase-form-control text-input" id="exampleInputEmail2" name="email" value="<?php echo e(old('email')); ?>">
								<?php if($errors->has('email')): ?>
							    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
							    <?php endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<div class="col-md-6 col-sm-6">
								<label class="info-title" for="exampleInputEmail1">Name <span>*</span></label>
								<input type="text" class="form-control unicase-form-control text-input" id="exampleInputEmail1" name="name" value="<?php echo e(old('name')); ?>">
								<?php if($errors->first('name')): ?>
							    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
							    <?php endif; ?>
							</div>
							<div class="col-md-6 col-sm-6">
								<label class="info-title" for="exampleInputEmail1">Phone Number <span>*</span></label>
								<input type="number" class="form-control unicase-form-control text-input" id="exampleInputEmail1" name="mobile_number" value="<?php echo e(old('mobile_number')); ?>">
								<?php if($errors->first('mobile_number')): ?>
							    <span class="text-danger"><?php echo e($errors->first('mobile_number')); ?></span>
							    <?php endif; ?>
							</div>
								
						</div>
						<div class="form-group row">
							<div class="col-sm-6 col-md-6">
								<label class="info-title" for="exampleInputEmail1">Password <span>*</span></label>
								<input type="password" class="form-control unicase-form-control text-input" id="exampleInputEmail1" name="password" >
								<?php if($errors->first('password')): ?>
							    <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
							    <?php endif; ?>
							</div>

							<div class="col-sm-6 col-md-6">
								<label class="info-title" for="exampleInputEmail1">Confirm Password <span>*</span></label>
								<input type="text" class="form-control unicase-form-control text-input" id="exampleInputEmail1" name="password_confirmation" >
								<?php if($errors->first('password_confirmation')): ?>
							    <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
							    <?php endif; ?>
							</div>	
						</div>
						<button type="submit" class="btn-upper btn btn-primary checkout-page-button">Sign Up</button>
					</form>
				</div>	
			</div>
		</div>
		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>