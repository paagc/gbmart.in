
<html>
<head>
	<title>GBMart Payments</title>

	<!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
	<h2 style="text-align: center;">Please wait for payment options...</h2>
	<h4 style="text-align: center;">Do not reload or close this page.</h4>
	<form id="pay_form" name="pay_form" action="https://secure.ebs.in/pg/ma/payment/request" method="POST" style="display: none;">
		<?php $__currentLoopData = $parameters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<input type="submit" value="Submit">
	</form>
	<script>
		window.onload = function() {
			document.pay_form.submit();
		};
	</script>
</body>
</html>
