<?php $__env->startSection('content_header'); ?>
<h1>
	Approved Orders
</h1>
<ol class="breadcrumb">
	<li><a href="/admin">Home</a></li>
	<li class="active">Approved Orders</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-body">
				<form action="/admin/orders/pending" method="GET">
					<table class="table table-bordered">
						<thead>
							<tr>
								<th>#</th>
								<th>Seller</th>
								<th>Product</th>
								<th>Count</th>
								<th>Price</th>
								<th>Delivery Charge</th>
								<th>Payment Method</th>
								<th>Placed at</th>
							</tr>
						</thead>
						<tbody>
							<?php $__empty_1 = true; $__currentLoopData = $approved_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($index+1); ?></td>
								<td><?php echo e($order->seller_product->seller->name); ?> (<?php echo e($order->seller_product->seller->mobile_number); ?>)</td>
								<td><?php echo e($order->seller_product->product->name); ?></td>
								<td><?php echo e($order->count); ?></td>
								<td><?php echo e($order->price); ?></td>
								<td><?php echo e($order->delivery_charge); ?></td>
								<td><?php echo e($order->payment_method); ?></td>
								<td><?php echo e($order->created_at); ?></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr>
								<td colspan="8" class="text-center">No Approved Orders Available</td>
							</tr>
							<?php endif; ?>
						</tbody>
					</table>
				</form>
			</div>
			<div class="box-footer clearfix">
				<?php echo e($approved_orders->appends(app('request')->all())->render()); ?>

			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>