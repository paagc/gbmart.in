<?php $__env->startSection('content_header'); ?>
<h1>
  Sellers
</h1>
<ol class="breadcrumb">
  <li><a href="#">Home</a></li>
  <li class="active">Sellers</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-body">
				<form action="/admin/sellers" method="GET">
					<table class="table table-bordered">
						<thead>
							<th>#</th>
							<th>Name</th>
							<th>Email</th>
							<th>Mobile Number</th>
							<th>Status</th>
							<th>Action</th>
						</thead>
						<tbody>
							<tr>
								<th></th>
								<th>
									<div class="form-group">
										<input type="text" name="name" class="form-control" placeholder="" <?php if(app('request')->has('name')): ?> value="<?php echo e(app('request')->get('name')); ?>" <?php endif; ?>>
									</div>
								</th>
								<th>
									<div class="form-group">
										<input type="text" name="email" class="form-control" placeholder="" <?php if(app('request')->has('email')): ?> value="<?php echo e(app('request')->get('email')); ?>" <?php endif; ?>>
									</div>
								</th>
								<th>
									<div class="form-group">
										<input type="text" name="mobile_number" class="form-control" placeholder="" <?php if(app('request')->has('mobile_number')): ?> value="<?php echo e(app('request')->get('mobile_number')); ?>" <?php endif; ?>>
									</div>
								</th>
								<th></th>
								<th>
									<button class="btn btn-primary btn-sm" type="submit">Filter</button>
								</th>
							</tr>
							<?php $__empty_1 = true; $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<?php if($seller->hasRole('seller')): ?>
							<tr>
								<td><?php echo e($index+1); ?></td>
								<td><?php echo e($seller->name); ?></td>
								<td><?php echo e($seller->email); ?></td>
								<td><?php echo e($seller->mobile_number); ?></td>
								<td><?php echo e($seller->status); ?></td>
								<td>
									<?php if($seller->status == 'PENDING'): ?>
									<a href="/admin/sellers/activate/<?php echo e($seller->id); ?>" class="btn btn-primary btn-sm">Activate</a>
									<?php elseif($seller->status == 'INACTIVE'): ?>
									<a href="/admin/sellers/enable/<?php echo e($seller->id); ?>" class="btn btn-warning btn-sm">Enable</a>
									<?php elseif($seller->status == 'ACTIVE'): ?>
									<a href="/admin/sellers/disable/<?php echo e($seller->id); ?>" class="btn btn-danger btn-sm">Disable</a>
									<?php endif; ?>
								</td>
							</tr>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5"><center>No Seller Available</center></td>
                            </tr>
                            <?php endif; ?>
						</tbody>
					</table>
				</form>
			</div>
			<div class="box-footer clearfix">
				<?php echo e($sellers->appends(app('request')->all())->render()); ?>

			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>