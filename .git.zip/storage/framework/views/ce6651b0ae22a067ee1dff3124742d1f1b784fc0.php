<?php $__env->startSection('content_header'); ?>
<h1>
	Google Shopping Content
</h1>
<ol class="breadcrumb">
	<li><a href="/admin">Home</a></li>
	<li class="active">Products in Google Shopping Content</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header with-border">
				<?php if(Session::has('success')): ?>
				<h4 class="text-center text-green"><?php echo e(Session::get('success')); ?></h4>
				<?php endif; ?>
				<h3>Existing Products In Google Shopping Content</h3>
			</div>

			<div class="box-body" style="height: 300px; overflow-y: scroll;">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>ID</th>
							<th>Name</th>
							<th>Description</th>
							<th>Link</th>
							<th>Condition</th>
							<th>Price</th>
							<th>Availability</th>
							<th>Image Link</th>
							<th>Brand</th>
						</tr>
					</thead>
					<tbody style="height: 400px; overflow-y: scroll;">
						<?php $__currentLoopData = $existingProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($product->offerId); ?></td>
							<td style="width: 100px;"><?php echo e($product->title); ?></td>
							<td style="width: 200px;"><?php echo e($product->description); ?></td>
							<td style="width: 100px; word-break: break-all;"><a href="<?php echo e($product->link); ?>" style="width: 100px; word-break: break-all;"><?php echo e($product->link); ?></a></td>
							<td><?php echo e($product->condition); ?></td>
							<td><?php echo e($product->price->value); ?></td>
							<td><?php echo e($product->availability); ?></td>
							<td style="width: 100px; word-break: break-all;"><a href="<?php echo e($product->imageLink); ?>" style="width: 100px; word-break: break-all;"><?php echo e($product->imageLink); ?></a></td>
							<td><?php echo e($product->brand); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
		<form method="POST" action="/admin/google-merchant-products">
			<?php echo e(csrf_field()); ?>

			<input type="hidden" name="access_token" value="<?php echo e($google_access_token); ?>">
			<div class="box">
				<div class="box-header with-border">
					<h3>Products In GBMart</h3>
					<h5>Note: While updating, above products will be deleted, and below selected products will be inserted.</h5>
				</div>

				<div class="box-body" style="height: 300px; overflow-y: scroll;">
					<table class="table table-bordered">
						<thead>
							<tr>
								<td><input type="checkbox" class="check-products" checked></td>
								<th>ID</th>
								<th>Name</th>
								<th>Description</th>
								<th>Link</th>
								<th>Condition</th>
								<th>Price</th>
								<th>Availability</th>
								<th>Image Link</th>
								<th>Brand</th>
							</tr>
						</thead>
						<tbody style="height: 400px; overflow-y: scroll;">
							<?php $__currentLoopData = $inputProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><input type="checkbox" class="check-product" name="productIds[]" value="<?php echo e($product['offerId']); ?>" checked></td>
								<td><?php echo e($product['offerId']); ?></td>
								<td style="width: 100px;"><?php echo e($product['title']); ?></td>
								<td style="width: 200px;"><?php echo e($product['description']); ?></td>
								<td style="width: 100px; word-break: break-all;"><a href="<?php echo e($product['link']); ?>" style="width: 100px; word-break: break-all;"><?php echo e($product['link']); ?></a></td>
								<td><?php echo e($product['condition']); ?></td>
								<td><?php echo e($product['price.value']); ?></td>
								<td><?php echo e($product['availability']); ?></td>
								<td style="width: 100px; word-break: break-all;"><a href="<?php echo e($product['imageLink']); ?>" style="width: 100px; word-break: break-all;"><?php echo e($product['imageLink']); ?></a></td>
								<td><?php echo e($product['brand']); ?></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
				<div class="box-footer">
					<button type="submit" class="btn btn-info">Submit</button>
				</div>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
	$(document).ready(function () {
		$('input.check-products').change(function () {
			var checked = $(this).prop('checked');
			$('input.check-product').each(function () {
				$(this).prop('checked', checked);
			});
		});

		$('input.check-product').change(function () {
			var checked = true;
			$('input.check-product').each(function () {
				var thisChecked = $(this).prop('checked');
				if (!thisChecked) {
					checked = thisChecked;
				}
			});
			$('input.check-products').prop('checked', checked);
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>