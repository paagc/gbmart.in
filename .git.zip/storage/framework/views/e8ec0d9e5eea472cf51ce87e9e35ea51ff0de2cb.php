<?php $__env->startSection('content_header'); ?>
<h1>
	Create A New Sub Category
</h1>
<ol class="breadcrumb">
	<li><a href="/admin">Home</a></li>
	<li><a href="/admin/sub-categories">Sub Categories</a></li>
	<li class="active">Create</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-6">
		<div class="box box-primary">
			<?php if(Session::has('error')): ?>
			<p class="text-red text-center"><?php echo e(Session::get('error')); ?></p>
			<?php endif; ?>
			<?php if(Session::has('success')): ?>
			<p class="text-green text-center"><?php echo e(Session::get('success')); ?></p>
			<?php endif; ?>
			<form role="form" action="/admin/sub-categories/create" method="POST">
				<?php echo e(csrf_field()); ?>

				<div class="box-body">
					<div class="form-group">
						<label for="inputCategory">Category</label>
						<select name="category_id" class="form-control" id="inputCategory">
							<option></option>
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($category->id); ?>" <?php if(old('category_id') == $category->id): ?> selected <?php endif; ?>><?php echo e($category->display_name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					<div class="form-group">
						<label for="inputName">Name</label>
						<input type="text" name="display_name" class="form-control" id="inputName" placeholder="Enter sub category name" value="<?php echo e(old('display_name')); ?>">
					</div>
				</div>
				<div class="box-footer">
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>