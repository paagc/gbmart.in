
<html>
<head>
	<title>GBMart Payments</title>

	<!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
	<?php if(app('request')->has('ResponseCode') && app('request')->get('ResponseCode') == '0'): ?>
	<h2 style="text-align: center;">Your payment was successful. Redirecting to home page...</h2>
	<h4 style="text-align: center;">Do not reload or close this page.</h4>
	<?php else: ?>
	<h2 style="text-align: center;">Your payment has failed. Redirecting to checkout page...</h2>
	<h4 style="text-align: center;">Do not reload or close this page.</h4>
	<?php endif; ?>
	<form id="pay_form" name="pay_form" action="https://secure.ebs.in/pg/ma/payment/request" method="POST" style="display: none;">
	</form>
	<script>
		window.onload = function() {
			<?php if(app('request')->has('ResponseCode') && app('request')->get('ResponseCode') == '0'): ?>
			window.location.href="/";
			<?php else: ?>
			window.location.href="/store/checkout";
			<?php endif; ?>
		};
	</script>
</body>
</html>
