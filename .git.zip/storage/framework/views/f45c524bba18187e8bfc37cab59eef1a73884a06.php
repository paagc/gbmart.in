<?php $__env->startSection('content_header'); ?>
<h1>
  Dashboard 
  <small>Reports and more</small>
</h1>
<ol class="breadcrumb">
  <li><a href="#">Home</a></li>
  <li class="active">Dashboard</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h2>Under Development</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>