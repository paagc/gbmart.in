<?php $__env->startSection('content_header'); ?>
<h1>
	Home Slides
</h1>
<ol class="breadcrumb">
	<li><a href="/admin">Home</a></li>
	<li class="active">Home Slides</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header with-border">
				<a href="/admin/home-slide/create" class="btn btn-success pull-right">Create Slide</a>
			</div>

			<div class="box-body">
				<form method="GET" action="/admin/home-slide">
					<table class="table table-bordered">
						<thead>
							<tr>
								<th>#</th>
								<th>Title</th>
								<th>Image</th>
								<tH>Link URL</th>
								<th>Status</th>
								<th>Actions</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td></td>
								<td><input type="text" name="title" placeholder="Search for title" class="form-control" <?php if(app('request')->has('title')): ?> value="<?php echo e(app('request')->get('title')); ?>" <?php endif; ?>></td>
								<td></td>
								<td><input type="text" name="link_url" placeholder="Link URL" class="form-control" <?php if(app('request')->has('link_url')): ?> value="<?php echo e(app('request')->get('link_url')); ?>" <?php endif; ?>></td>
								<td></td>
								<td><button type="submit" class="btn btn-primary">GO</button></td>
							</tr>
							<?php $__empty_1 = true; $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($index+1); ?></td>
								<td><?php echo e($slide->title); ?></td>
								<td><a href="<?php echo e($slide->image_url); ?>" class="btn btn-primary btn-sm" target="_blank">View Image</a></td>
								<td><a href="<?php echo e($slide->link_url); ?>" target="_blank"><?php echo e($slide->link_url); ?></a></td>
								<td><?php echo e($slide->status); ?></td>
								<td>
									<?php if($slide->status == 'ACTIVE'): ?>
									<a href="/admin/home-slide/<?php echo e($slide->id); ?>/destroy" title="Deactivate" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
									<?php else: ?>
									<a href="/admin/home-slide/<?php echo e($slide->id); ?>/active" title="Activate" class="btn btn-xs btn-warning"><i class="fa fa-edit"></i></a>
									<?php endif; ?>

									<a href="/admin/home-slide/<?php echo e($slide->id); ?>/edit" title="Edit" class="btn btn-xs btn-primary"><i class="fa fa-pencil"></i></a>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr>
								<td colspan="6" class="text-center">No slide to display</td>
							</tr>
							<?php endif; ?>
						</tbody>
					</table>
				</form>
			</div>
			<div class="box-footer clearfix">
				<?php echo e($slides->appends(app('request')->all())->render()); ?>

			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>