<?php $__env->startSection('content_header'); ?>
<h1>
  Products 
</h1>
<ol class="breadcrumb">
  <li><a href="/seller">Home</a></li>
  <li class="active">Your Products</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header with-border">
				<a href="/seller/seller-products/create" class="btn btn-success pull-right">Add New Product</a>
			</div>

			<div class="box-body">
				<table class="table table-bordered">
					<tbody>
						<tr>
							<th>#</th>
							<th>Display Name</th>
							<tH>Brand</th>
							<th>Category</th>
							<th>Sub Categeory</th>
							<th>Original Price</th>
							<th>Your Price</th>
							<th>Status</th>
							<th>Actions</th>
						</tr>
						<tr>
							<form action="/seller/seller-products" method="GET">
								<th></th>
								<th>
									<div class="form-group">
										<input type="text" name="display_name" class="form-control" placeholder="" <?php if(app('request')->has('display_name')): ?> value="<?php echo e(app('request')->get('display_name')); ?>" <?php endif; ?>>
									</div>
								</th>
								<th>
									<div class="form-group">
										<input type="text" name="brand" class="form-control" placeholder="" <?php if(app('request')->has('brand')): ?> value="<?php echo e(app('request')->get('brand')); ?>" <?php endif; ?>>
									</div>
								</th>
								<th>
									<div class="form-group">
										<select name="category_name" class="form-control">
											<option></option>
											<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($category->name); ?>" <?php if(app('request')->has('category_name') && app('request')->get('category_name') == $category->name): ?> selected <?php endif; ?>><?php echo e($category->display_name); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</th>
								<th>
									<div class="form-group">
										<select name="sub_category_name" class="form-control">
											<option></option>
											<?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($sub_category->name); ?>" <?php if(app('request')->has('sub_category_name') && app('request')->get('sub_category_name') == $sub_category->name): ?> selected <?php endif; ?>><?php echo e($sub_category->display_name); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</div>
								</th>
								<th></th>
								<th></th>
								<th>
									<div class="form-group">
										<select name="status" class="form-control">
											<option></option>
											<option value="ACTIVE" <?php if(app('request')->has('status') && app('request')->get('status') == 'ACTIVE'): ?> selected <?php endif; ?>>ACTIVE</option>
											<option value="INACTIVE" <?php if(app('request')->has('status') && app('request')->get('status') == 'INACTIVE'): ?> selected <?php endif; ?>>INACTIVE</option>
										</select>
									</div>
								</th>
								<th>
									<button type="submit" class="btn btn-primary">Filter</button>
								</th>
							</form>
						</tr>
						<?php if(count($seller_products) == 0): ?>
						<tr>
							<td colspan="6">No records found.</td>
						</tr>
						<?php endif; ?>
						<?php $__currentLoopData = $seller_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $seller_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e((($page - 1) * $page_size) + $index + 1); ?></td>
							<td><?php echo e($seller_product->product->display_name); ?></td>
							<td><?php echo e($seller_product->product->brand); ?></td>
							<td><?php echo e($seller_product->product->category->display_name); ?></td>
							<td><?php echo e($seller_product->product->sub_category->display_name); ?></td>
							<td><?php echo e($seller_product->product->original_price); ?></td>
							<td><?php echo e($seller_product->seller_price); ?></td>
							<td><?php echo e($seller_product->status); ?></td>
							<td>
								<?php if($seller_product->status == 'ACTIVE'): ?>
								<a class="btn btn-xs btn-danger" href="/seller/seller-products/<?php echo e($seller_product->id); ?>/status/INACTIVE"><i class="fa fa-window-close"></i></a>
								<?php endif; ?>
								<?php if($seller_product->status == 'INACTIVE'): ?>
								<a class="btn btn-xs btn-success" href="/seller/seller-products/<?php echo e($seller_product->id); ?>/status/ACTIVE"><i class="fa fa-check-square"></i></a>
								<?php endif; ?>
								<a href="/seller/seller-products/<?php echo e($seller_product->id); ?>/edit" title="Edit" class="btn btn-xs btn-info"><i class="fa fa-pencil"></i></a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
			<div class="box-footer clearfix">
				<?php echo e($seller_products->appends(app('request')->all())->render()); ?>

			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('seller.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>